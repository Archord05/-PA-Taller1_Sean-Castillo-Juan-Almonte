package Services;
import Model.*;
import com.sun.source.tree.UsesTree;
import ucn.*;
import ucn.StdIn;
import ucn.StdOut;

import java.io.IOException;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) throws IOException {
    configuracion();

        }

        //Modificaciones principales 21-04:

        //Cambio dentro de los parametros para "menu" , "menuprincipal" y "iniciarSesion"
        //Con el fin de la comunicación entre metodos dentro del main.

        // cambio dentro de "String Usuario Stdin.readAll()" se cambio a String Usuario Stdin.ReadLine()"
        // ya que no leia correctamente el documento de texto

        // Añadido "BuscarVideojuego"

        //nota: ventaVideojuego deberia funcionar similar a la estructura de busquedaVideojuego
        //      considerando claro otros algoritmos para añadir a las estadisticas. ni idea ahi la verdad

        //nota: Las validaciones son los amigos que hicimos en el camino

        //"buscarVideojuegos" tiene errores solo funciona correctamente la busqueda por codigo y printea lo demas sin
        // haberse cumplido la condición probablemente sea
        // un mal manejo de la estructura de las condicionales.




    //MODIFICACIONES   generales hechas hechas
    //Mejora en los menus
    //actualizacion de como ingresar las opciones del programa,poner si y no era engorroso y se podia caer,estandarice el ingresar opcion numerica
    //creacion de listaEstadisticas y estaditicas encargadas de trabajar los datos especificos para estaditicas
    //termino de logica interna de 3 d 5 metodos de estadisticas
    //creacion de validacion en el 80% del codigo la linea 167 se puede morir , hacer un try cach o alguna validacion
    //se arreglo el fallo que se cayera  en la linea de codigo 218 debido a que no se tuvo en cuenta la logica del metodo llamado
    //falta realizar las estadisticas
    //SI HACES alguna opcion extra o mini menu avisa luego para poder dejarla bonita
    //tengo la idea de como hacer el mensaje final,te mande una imagen pero trabajare si hay tiempo cuando se termine el codigo
//falta hacer validacio del rut y formato, lo investidagare

        public static void configuracion() throws IOException {

        //Los datos son fijos bajo los criterios del enunciado por ende no es necesario preguntar por el tamaño

        ListaEmpleados datosEmpleados= new ListaEmpleados(30);
        ListaVideojuego datosVideojuego = new ListaVideojuego(30);
        ListaClientes datosClientes = new ListaClientes(30);
        ListaEstadisticas datosEstadisticas=new ListaEstadisticas(30);

             String Archivo1=("Juegos.txt");
            String Archivo2=("Trabajadores.txt");
        datosVideojuego.lecturaArchivo(Archivo1);
        datosEmpleados.lecturaArchivo(Archivo2);
        datosVideojuego.GeneradorDeDescuento();
            menu(datosEmpleados, datosVideojuego, datosClientes,datosEstadisticas);

        datosVideojuego.GeneradorDeDescuento();

    }

    public static void menu(ListaEmpleados datosEmpleados, ListaVideojuego datosVideojuegos, ListaClientes datosClientes,ListaEstadisticas datosEstadisticas){
        boolean llave=true;

        while (llave) {
            StdOut.println("╔═══════════════════════════════════════════╗");
            StdOut.println("║      Bienvenido al sistema de ventas      ║");
            StdOut.println("╠═══════════════════════════════════════════╣");
            StdOut.println("║ Ingrese la opción para continuar          ║");
            StdOut.println("║ (1) - Iniciar Sesión                      ║");
            StdOut.println("║ (2) - Cerrar Programa                     ║");
            StdOut.println("╚═══════════════════════════════════════════╝");
            StdOut.print("* : ");
            String opcion= StdIn.readLine();
            switch (opcion){

                case "1" -> iniciarSesion(datosEmpleados, datosVideojuegos, datosClientes,datosEstadisticas);
                case "2" -> llave=false;
                default -> StdOut.println("Ingrese opcion valida");
            }
        }
    }

    //Inicio de sesion utiliza la Listaempleados la cual nombre datosEmpleados
    public static void iniciarSesion(ListaEmpleados datosEmpleados, ListaVideojuego datosVideojuego, ListaClientes datosClientes,ListaEstadisticas datosEstadisticas){
        System.out.println("Bienvenido, Ingrese sus credenciales para acceder");

        System.out.print("Usuario: ");
        String usuarioTeclado = StdIn.readLine();   //PORQUE O RABANOS FUNCIONA COM O REDLINE, ESTOU TENTANDO DESCOBRIR O MOTIVO HÁ UMA HORA. VOU ACESSAR O SITE ****** atte: juan
        int posicion = datosEmpleados.buscarEmpleadoUsuario(usuarioTeclado);  //se cae el programa cuando no ingresas nobmre

        if (posicion != -1){

            Empleado usuario = datosEmpleados.obtenerPosicion(posicion);  //
            datosEmpleados.EmpleadoActual(usuarioTeclado);
            System.out.println("Bienvenido " + usuario.getUsuario()+ " porfavor ingrese su contraseña:");
        }
        else {
            System.out.println("Usuario incorrecto pruebe denuevo");
            iniciarSesion(datosEmpleados, datosVideojuego, datosClientes,datosEstadisticas);
        }

        System.out.print("Contraseña: ");
        String contraseniaTeclado = StdIn.readLine();
        int posicion2 = datosEmpleados.buscarEmpleadoContrasenia(contraseniaTeclado,posicion);

        if (posicion2 != -1){
            Empleado contrasenia = datosEmpleados.obtenerPosicion(posicion2);

            System.out.println("Ingresaste");
            System.out.println("Bienvenido elija una de las siguiente opciones");
            menuPrincipal(datosEmpleados, datosVideojuego, datosClientes,datosEstadisticas);
        }
        else {
            System.out.println("Contraseña incorrecta pruebe denuevo");
            iniciarSesion(datosEmpleados, datosVideojuego, datosClientes,datosEstadisticas);
    }



    }

    public static void menuPrincipal(ListaEmpleados datosEmpleados, ListaVideojuego datosVideojuego, ListaClientes datosClientes,ListaEstadisticas datosEstadisticas){
        boolean llave2=true;

        while (llave2) {
            StdOut.println("╔════════════════════════╗");
            StdOut.println("║      Menu Principal    ║");
            StdOut.println("╠════════════════════════╣");
            StdOut.println("║ Ingrese su opción:     ║");
            StdOut.println("║ 1) Vender Videojuego   ║");
            StdOut.println("║ 2) Buscar Videojuego   ║");
            StdOut.println("║ 3) Menú de Estadísticas║");
            StdOut.println("║ 4) Cerrar Sesión       ║");
            StdOut.println("╚════════════════════════╝");

            StdOut.print("* : ");
            String opcion= StdIn.readLine();
            switch (opcion){

                case "1":vendervideojuegos(datosEmpleados, datosVideojuego, datosClientes,datosEstadisticas);  //excepcion si pongo numero se muere
                case "2":buscarvideojuegos(datosEmpleados, datosVideojuego, datosClientes,datosEstadisticas);
               // case "3":menuEstadisticas();
                case "4":menu(datosEmpleados, datosVideojuego,datosClientes,datosEstadisticas);
                default:StdOut.println("Ingrese opcion valida");
            }
        }

    }

    //buscarVideojuego:
    //Se le pide al usuario ingresar por teclado el codigo unico o nombre(Aun no funciona correctamente pero esta es
    // la estructura), consecuentemente utiliza el dato ingresado para comparar dentro de la "ListaVideojuego" en base a
    // "BuscarVideojuego"
    // Si lo encuentra declaramos a la clase "Videojuego" y la nombramos en este caso "codigo" a continuación
    // printea los datos dentro de la clase llamandolos por ejemplo con la funcion "codigo.getCodigounico()"
    // cabe añadir que los datos son obtenidos del documento de texto (Juegos.txt)
    // atte: Juan
    public static void buscarvideojuegos(ListaEmpleados datosEmpleados, ListaVideojuego datosVideojuegos, ListaClientes datosClientes,ListaEstadisticas datosEstadisticas){
        System.out.println("Ingrese el nombre o codigo unico del videojuego");
        String buscarDatoIngresado = StdIn.readLine();      //se muere
        int posicion = datosVideojuegos.BuscarVideojuegoCodigo(buscarDatoIngresado);
        int posicion2 = datosVideojuegos.BuscarVideojuegoNombre(buscarDatoIngresado);

        if (posicion != -1){
            Videojuego codigo = datosVideojuegos.obtenerPosicionVideojuego(posicion);

            StdOut.println("╔═══════════════════════╗");
            StdOut.println("║      Videojuego       ║");
            StdOut.println("╚═══════════════════════╝");
            StdOut.println(" Código:         " + codigo.getCodigoUnico());
            StdOut.println(" Nombre:         " + codigo.getNombre());
            StdOut.println(" Precio:         " + codigo.getPrecio());
            StdOut.println(" Género:         " + codigo.getGenero());
            StdOut.println(" Clasificación:  " + codigo.getClasificacionEdad());
            StdOut.println(" Desarrolladora: " + codigo.getCompañia());
            StdOut.println(" Plataforma:     " + codigo.getPlataforma());
            StdOut.println("╚══════════════════════════╝");


            menuPrincipal(datosEmpleados, datosVideojuegos, datosClientes,datosEstadisticas);
        }
        else if (posicion2 != -1){     //aqui se cae
            Videojuego nombre = datosVideojuegos.obtenerPosicionVideojuego(posicion2);
            StdOut.println("╔════════════════════════════════════╗");
            StdOut.println("║           Videojuego               ║");
            StdOut.println("╚════════════════════════════════════╝");
            StdOut.println(" Código:            " + nombre.getCodigoUnico());
            StdOut.println(" Nombre:            " + nombre.getNombre());
            StdOut.println(" Precio:            " + nombre.getPrecio());
            StdOut.println(" Género:            " + nombre.getGenero());
            StdOut.println(" Clasificación:     " + nombre.getClasificacionEdad());
            StdOut.println(" Desarrolladora:    " + nombre.getCompañia());
            StdOut.println(" Plataforma:        " + nombre.getPlataforma());
            StdOut.println("╚═══════════════════════════════════");

            menuPrincipal(datosEmpleados, datosVideojuegos, datosClientes,datosEstadisticas);
        }
        else {
            System.out.println("Videojuego no encontrado intente denuevo");
            buscarvideojuegos(datosEmpleados, datosVideojuegos, datosClientes,datosEstadisticas);
        }
    }
    public static void vendervideojuegos(ListaEmpleados datosEmpleados,ListaVideojuego datosVideojuegos, ListaClientes datosClientes,ListaEstadisticas datosEstadisticas){
      String videojuegoporTeclado;
      String rutPorTeclado;
        StdOut.println("*******************************");
        StdOut.print("* : ");
        StdOut.println("Ingrese el videojuego que se desea  vender");
        videojuegoporTeclado=StdIn.readLine();
        String generoSeleccionado = "";
        double precioConDescuento = 0;
        double comision=0;
        String plataforma=" ";
        int posicion = datosVideojuegos.BuscarVideojuegoNombre(videojuegoporTeclado);
        Videojuego nombre = datosVideojuegos.obtenerPosicionVideojuego(posicion);
         if (posicion != -1){
             StdOut.println("╔════════════════════════════════════╗");
             StdOut.println("║           Videojuego               ║");
             StdOut.println("╚════════════════════════════════════╝");
             StdOut.println(" Código:            " + nombre.getCodigoUnico());
             StdOut.println(" Nombre:            " + nombre.getNombre());
             StdOut.println(" Precio:            " + nombre.getPrecio());
             StdOut.println(" Género:            " + nombre.getGenero());
             StdOut.println(" Clasificación:     " + nombre.getClasificacionEdad());
             StdOut.println(" Desarrolladora:    " + nombre.getCompañia());
             StdOut.println(" Plataforma:        " + nombre.getPlataforma());
             StdOut.println("╚═══════════════════════════════════");
            generoSeleccionado = nombre.getGenero();
            precioConDescuento = nombre.getPrecio();
             plataforma= nombre.getPlataforma();
        }
         else {
             System.out.println("Ingrese un nombre valido");
             vendervideojuegos(datosEmpleados, datosVideojuegos,datosClientes,datosEstadisticas);
         }

        StdOut.print("Ingrese su rut: ");
        StdOut.print("* : ");
        rutPorTeclado=StdIn.readLine();

        if(datosClientes.validacion(rutPorTeclado)){
            StdOut.println("╔════════════════════════════════════════╗");
            StdOut.println("║           Estimado Cliente             ║");
            StdOut.println("╚════════════════════════════════════════╝");
            StdOut.println(" Contamos con descuentos increíbles    ");
            StdOut.println(" todos los días.                        ");
            StdOut.println(" Hoy en GameTech contamos con            ");
            StdOut.println(" " + datosVideojuegos.getDescuentoAleatorio() + " al 30%. ");
            StdOut.println(" ¿Desea registrarse en nuestra tienda?   ");
            StdOut.println(" Ingrese la opción para continuar          ");
            StdOut.println("   (1)-Si                                  ");
            StdOut.println("   (2)-No                                  ");
            StdOut.println("╚════════════════════════════════════════╝");
            StdOut.print("* : ");
            String opcion=StdIn.readLine();

            switch (opcion){
                case "1":AgregarCliente(datosClientes);
                case "2": System.out.println("Se continuara con el proceso de compra");
                default:StdOut.println("Ingrese opcion valida");
            }
        }
        StdOut.println("Desea confirmar la compra del videojuego: "+videojuegoporTeclado);
        StdOut.println("╔══════════════════════════════════════════════════╗");
        StdOut.println("║     ¿Desea confirmar la compra del videojuego?   ║");
        StdOut.println("╠══════════════════════════════════════════════════╣");
        StdOut.println("║ " + videojuegoporTeclado + "                     ║");
        StdOut.println("║   (1)-Si                                         ║");
        StdOut.println("║   (2)-No                                         ║");
        StdOut.println("╚══════════════════════════════════════════════════╝");
        StdOut.print("* : ");
        String confirmar = StdIn.readLine();

        int posicion3 = datosClientes.buscarCliente(rutPorTeclado);

        if(posicion3!=-1){
        Cliente cliente = datosClientes.obtenerPosicionCliente(posicion3); //aqui muere debido a que busca en un arreglo vacio () deber arreglarlo

        //Logica para aplicar descuento let me cook                              //compra con descuento
        if (confirmar.equalsIgnoreCase("1") && cliente.getRut().equalsIgnoreCase(rutPorTeclado)) {
            if (datosVideojuegos.getDescuentoAleatorio().equalsIgnoreCase(generoSeleccionado)) {
                System.out.println("El nuevo precio del videojuego es: ");
                precioConDescuento = precioConDescuento - precioConDescuento * 0.3;
                System.out.println(videojuegoporTeclado);
                System.out.println(precioConDescuento);
                comision = precioConDescuento * 0.02;

                Estadisticas videojuegoComprado = new Estadisticas(videojuegoporTeclado,plataforma, "registrado", precioConDescuento, datosEmpleados.getEmpleadoActivo(), comision);
                registroventas(datosEstadisticas, videojuegoComprado);
                System.out.println("Compra Realizada");
            }
            if (!datosVideojuegos.getDescuentoAleatorio().equalsIgnoreCase(generoSeleccionado)) {
                System.out.println("Se realiza la compra de: ");
                System.out.println(videojuegoporTeclado);
                System.out.println(precioConDescuento);
                comision = precioConDescuento * 0.02;
                Estadisticas videojuegoComprado = new Estadisticas(videojuegoporTeclado,plataforma, "normal", precioConDescuento, datosEmpleados.getEmpleadoActivo(), comision);
                registroventas(datosEstadisticas, videojuegoComprado);
                System.out.println("Compra Realizada");
            }
        }
        if(posicion3>1){
            System.out.println("Se realiza la compra de: ");
            System.out.println(videojuegoporTeclado);
            System.out.println(precioConDescuento);
            comision = precioConDescuento * 0.02;
            Estadisticas videojuegoComprado = new Estadisticas(videojuegoporTeclado,plataforma, "normal", precioConDescuento, datosEmpleados.getEmpleadoActivo(), comision);
            registroventas(datosEstadisticas, videojuegoComprado);
            System.out.println("Compra Realizada");
        }
        }
        if (confirmar.equalsIgnoreCase("2")){
            System.out.println("Compra Cancelada");
        }
        if(!confirmar.equalsIgnoreCase("1")&&!confirmar.equalsIgnoreCase("2")) {
            System.out.println("Ingrese una opcion valida");
        }

        StdOut.println("Desea realizar la compra de otro videjuego: ");
        String opcion=StdIn.readLine();
        switch (opcion){
            case "Si": vendervideojuegos(datosEmpleados,datosVideojuegos, datosClientes,datosEstadisticas);
            case "No": menuPrincipal(datosEmpleados, datosVideojuegos, datosClientes,datosEstadisticas);
            default:StdOut.println("Ingrese opcion valida");
        }

    }

    public static void AgregarCliente(ListaClientes datosClientes){


        StdOut.println("Ingrese su rut");
        String rutPorTeclado = StdIn.readLine();
        StdOut.println("Ingrese su nombre Completo");
        String nombrePorTeclado = StdIn.readLine();
        StdOut.println("correo lectronico");
        String correoPorTeclado = StdIn.readLine();
        Cliente cliente = new Cliente(rutPorTeclado, nombrePorTeclado, correoPorTeclado);
        datosClientes.agregarClientes(cliente);
    }
    public static void menuEstadisticas(){
        boolean llave3=true;

        while (llave3) {                                    //falta hacer las funciones del main en estaDISTICAS revisa lo que hice
            StdOut.println("╔═══════════════════════════════════╗");
            StdOut.println("║        Menu Estadisticas          ║");
            StdOut.println("╠═══════════════════════════════════╣");
            StdOut.println("║ Ingrese una opción:               ║");
            StdOut.println("║ (1) Videojuego más vendido        ║");
            StdOut.println("║ (2) Plataforma con mayor ventas   ║");
            StdOut.println("║ (3) Ventas a clientes registrados ║");
            StdOut.println("║ (4) Imprimir ventas totales       ║");
            StdOut.println("║ (5) Trabajador con más ventas     ║");
            StdOut.println("║ (6) Menú anterior                 ║");
            StdOut.println("╚═══════════════════════════════════╝");
            StdOut.print("* : ");
            String opcion=StdIn.readLine();
            switch (opcion) {
                case "1": ;
                case "2": ;
                case "3": ;
                case "4": ;
                case "5": ;
                case "6": ;
                default:
                    StdOut.println("Ingrese opcion valida");
            }
        }
    }
    public static void registroventas(ListaEstadisticas DatosEstadisticas,Estadisticas videojuegoComprado){
        DatosEstadisticas.agregarEstadistica(videojuegoComprado);
    }
   public static void videojuegoMasVendido(){




    }
    }
