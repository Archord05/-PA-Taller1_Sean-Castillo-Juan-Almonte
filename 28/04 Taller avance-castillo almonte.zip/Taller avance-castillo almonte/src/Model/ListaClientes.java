package Model;

import ucn.StdOut;

public class ListaClientes {
    private Cliente[] arregloClientes;
    private  int cantidadMaxima;
    private  int cantidadActual;

    public ListaClientes(int cantidadMaxima){

        this.cantidadMaxima = cantidadMaxima;
        this.arregloClientes = new Cliente[this.cantidadMaxima];
        this.cantidadActual = 0;
    }

   public  boolean agregarClientes(Cliente cliente) {
       if (this.cantidadActual == 0) {
           this.arregloClientes[0] = cliente;
           this.cantidadActual++;
           return true;
       }
       this.arregloClientes[cantidadActual] = cliente;
       this.cantidadActual++;
       return true;
   }
   public boolean validacion(String rut){
       for (int i = 0; i < cantidadActual; i++) {
           if (this.arregloClientes[i].getRut().equalsIgnoreCase(rut)) {
               StdOut.println("El cliente ya existe en el registro");
               return false;
           }
       }
        return true;

   }
    public int buscarCliente(String rut){
        for (int i = 0; i < cantidadActual; i++) {
            if (this.arregloClientes[i].getRut().equalsIgnoreCase(rut)){
                return i;
            }
        }
        return -1;
    }

    public Cliente obtenerPosicionCliente(int posicion){
        return this.arregloClientes[posicion];
    }

    public Cliente[] getArregloClientes() {
        return arregloClientes;
    }

    public int getCantidadMaxima() {
        return cantidadMaxima;
    }

    public int getCantidadActual() {
        return cantidadActual;
    }


}
