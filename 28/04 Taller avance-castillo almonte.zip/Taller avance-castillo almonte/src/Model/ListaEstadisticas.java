package Model;

import ucn.StdOut;

public class ListaEstadisticas {
        private Estadisticas[] arregloEstadisticas;
        private  int cantidadMaxima;
        private  int cantidadActual;

        public ListaEstadisticas(int cantidadMaxima) {
            this.cantidadMaxima = cantidadMaxima;
            this.arregloEstadisticas = new Estadisticas[this.cantidadMaxima];
            this.cantidadActual = 0;
        }

        public boolean agregarEstadistica(Estadisticas estadisticas){
            if (this.cantidadActual == 0) {
                this.arregloEstadisticas[0] = estadisticas;
                this.cantidadActual++;
                return true;
            }
            this.arregloEstadisticas[cantidadActual] = estadisticas;
            this.cantidadActual++;
            return true;
        }
        //no me da la mente azlo
        //atentamente sean
        public String videojuegoMasVendido(Estadisticas estadisticas) {  //idea como logro saber cual es el dato mayotr
            String[] arregloAux = new String[this.cantidadMaxima];
            int cantidadAuxActual = 0;
            if (cantidadAuxActual == 0) {
                arregloAux[0] = estadisticas.getVideojuegoIngresado();
                cantidadAuxActual++;
            }
        return "Hola";
        }
        public String PlataformaConMayorVentas(Estadisticas estadisticas){                     //platadorma con mayores venta en teoria deberia funciar y deberias ingresar datos para validar eso
            int nintendo=0;                                                                     //recorremos la lista de los articulos vendidos con un for i,/ revisamos que coincidan los resultados con las 3 opciuones
            int xbox=0;                                                                         //multiplataforma sencillkamente agregamos a cada uno uno
            int playStation=0;                                                                  //el arreglo no contempla el caso de empate asi que creo que la logita a continuacion esta bien
            int mayor=0;                                                                        //comnprobamos si se cumple que efectivamente el dato mayor es uno de los presentados
            String nombreMayor=" ";                                                             //retornamos la respuesta como string

            for (int i = 0; i <this.cantidadActual ; i++) {
                if (this.arregloEstadisticas[i].getPlataforma().equalsIgnoreCase("nintendo")) {
                    nintendo++;

                }
                if (this.arregloEstadisticas[i].getPlataforma().equalsIgnoreCase("xbox")) {
                    xbox++;

                }
                if (this.arregloEstadisticas[i].getPlataforma().equalsIgnoreCase("PlayStation")) {
                    playStation++;

                }
                if (this.arregloEstadisticas[i].getPlataforma().equalsIgnoreCase("multiplataforma")) {
                    playStation++;
                    xbox++;
                    nintendo++;

                }
            }
           if(xbox<playStation && playStation <nintendo){
               mayor=nintendo;
               nombreMayor=" nintendo";
           }
            if(xbox>playStation && playStation >nintendo){
                mayor=xbox;
                nombreMayor=" xbox";
            }
            if(xbox<playStation && playStation >nintendo){
                mayor=playStation;
                nombreMayor="playStation";
            }
       String elmayor=("La compañia que mas vendio fue ")+nombreMayor+(" con las siguientes ventas")+(mayor);
            return elmayor;
        }
        public int VentasAClientesRegistrados(Estadisticas estadisticas){                                   //acomulador sencillo que guarda  las ventas los clientes registrados
                                                                                                            //devuelve el numero de ventas como int
          int cantidadVendidos=0;

            for (int i = 0; i <this.cantidadActual ; i++) {
               if(this.arregloEstadisticas[i].getClientePremium().equalsIgnoreCase("registrado")){
                   cantidadVendidos++;
               }
            }

            return cantidadVendidos;
        }

        public double imprimirVentasTotales(Estadisticas estadisticas){                                                     //acomulador sencillo que guarda el dinero vendido de las ventas totales
                                                                                                                            //devuelve el dato como double
            double cantidadVentasTotales=0;
            double cantidadVentas=0;
            for (int i = 0; i <this.cantidadActual ; i++) {
               cantidadVentas=this.arregloEstadisticas[i].getDineroRecaudado();
                cantidadVentasTotales=cantidadVentasTotales+cantidadVentas;
                }
            return cantidadVentasTotales;
        }

        public boolean trabajadorConMasVentas(Estadisticas estadisticas){
        //toca hacer
            return true;





        }




        public Estadisticas[] getArregloEstadisticas() {
            return arregloEstadisticas;
        }

        public int getCantidadMaxima() {
            return cantidadMaxima;
        }

        public int getCantidadActual() {
            return cantidadActual;
        }


    }


