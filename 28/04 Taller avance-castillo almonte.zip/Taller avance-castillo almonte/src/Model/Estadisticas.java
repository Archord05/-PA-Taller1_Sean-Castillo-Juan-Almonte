package Model;

import ucn.StdOut;

public class Estadisticas {
    private String videojuegoIngresado;
    private String plataforma;
    private String ClientePremium;
    private double dineroRecaudado;
    private String trabajadorConMasVentas;
    private double comision;

    private int videojuegoMasVendido;

    public Estadisticas(String videojuegoIngresado,String plataforma, String clientePremium, double dineroRecaudado, String trabajadorConMasVentas, double comision) {
        this.videojuegoIngresado = videojuegoIngresado;
        this.plataforma=plataforma;
        this.ClientePremium = clientePremium;
        this.dineroRecaudado = dineroRecaudado;
        this.trabajadorConMasVentas = trabajadorConMasVentas;
        this.comision = comision;
    }

    public String getVideojuegoIngresado() {
        return videojuegoIngresado;
    }

    public String getClientePremium() {
        return ClientePremium;
    }

    public double getDineroRecaudado() {
        return dineroRecaudado;
    }

    public String getTrabajadorConMasVentas() {
        return trabajadorConMasVentas;
    }

    public double getComision() {
        return comision;
    }

    public String getPlataforma() {
        return plataforma;
    }

    public int getVideojuegoMasVendido() {
        return videojuegoMasVendido;
    }
}
