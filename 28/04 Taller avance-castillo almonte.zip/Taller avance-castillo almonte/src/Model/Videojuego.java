package Model;

public class Videojuego {
    private String codigoUnico;
    private  String nombre;
    private double precio;
    private  String genero;
    private String  clasificacionEdad;
    private  String compañia;
    private  String plataforma;
    private String generoDescuento;
    private  int descuento;

    public Videojuego(String codigoUnico, String nombre, double precio, String genero, String clasificacionEdad,  String compañia, String plataforma, String generoDescuento, int descuento) {
        this.codigoUnico = codigoUnico;
        this.nombre = nombre;
        this.precio = precio;
        this.genero = genero;
        this.clasificacionEdad = clasificacionEdad;
        this.compañia=compañia;
        this.plataforma = plataforma;
        this.generoDescuento = generoDescuento;
        this.descuento = descuento;
    }

    public Videojuego(String codigoUnico, String nombre, double precio, String genero, String clasificacionEdad, String compañia, String plataforma) {
        this.codigoUnico = codigoUnico;
        this.nombre = nombre;
        this.precio = precio;
        this.genero = genero;
        this.clasificacionEdad = clasificacionEdad;
        this.compañia = compañia;
        this.plataforma = plataforma;
    }

    public String getCodigoUnico() {
        return codigoUnico;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public String getGenero() {
        return genero;
    }

    public String getClasificacionEdad() {
        return clasificacionEdad;
    }

    public String getCompañia() {
        return compañia;
    }

    public String getPlataforma() {
        return plataforma;
    }

    public String getGeneroDescuento() {
        return generoDescuento;
    }

    public int getDescuento() {
        return descuento;
    }

    public void setCodigoUnico(String codigoUnico) {
        this.codigoUnico = codigoUnico;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public void setClasificacionEdad(String clasificacionEdad) {
        this.clasificacionEdad = clasificacionEdad;
    }

    public void setCompañia(String compañia) {
        this.compañia = compañia;
    }

    public void setPlataforma(String plataforma) {
        this.plataforma = plataforma;
    }

    public void setGeneroDescuento(String generoDescuento) {
        this.generoDescuento = generoDescuento;
    }

    public void setDescuento(int descuento) {
        this.descuento = descuento;
    }
}
