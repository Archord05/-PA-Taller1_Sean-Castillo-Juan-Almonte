package Model;
import ucn.ArchivoEntrada;
import ucn.Registro;

import java.io.IOException;

public class ListaVideojuego {
    private Videojuego[] arregloVideojuego;
    private  int cantidadMaxima;
    private  int cantidadActual;
    private String descuentoAleatorio;
    private  String ventaVidejuego;                   ///estoy medio dormido , reviar el docunmentoa anttteri0or se algo falla, pido su comprecionm de antemano
    private  int cantidadMaximaVentas;
    private  int cantidadActualDeDatosVendidos;
    public ListaVideojuego(int cantidadMaxima) {
       if(cantidadMaxima<=0){
           throw new IllegalArgumentException("La cantidad no puede ser cero");
       }
        this.cantidadMaxima = cantidadMaxima;
        this.arregloVideojuego=new Videojuego[this.cantidadMaxima];
        this.cantidadActual =0;
    }

    //Verificar la lectura de archivos principalmente la forma de ingresar los mismos


     public void lecturaArchivo(String nombreArchivo) throws IOException {                //logica de agregar videojuegos, ordeno el codigo luiego perdon que son las 1:41 de la mañana
        // creamos un arreglo con una excesiva cantidad para que no se llene el arreglo
     ArchivoEntrada archivoEntrada = new ArchivoEntrada(nombreArchivo);                     //declaramos el archivo entrada

     while (!archivoEntrada.isEndFile()) {                                                    //condicional para leer la cantidad variable de datos

         Registro Videojuego=archivoEntrada.getRegistro();                                  //creamos enl registro para poder extraer datos
         String codigoUnico = Videojuego.getString();                                      //Usaremos nuestro registro para sacar la informacion que hemos adquiridos
         String nombre=Videojuego.getString();
         double precio =Videojuego.getDouble();                                           //sacamaos el precio como double del programa
         String genero = Videojuego.getString();
         String compañia= Videojuego.getString();
         String clasificacionEdad =Videojuego.getString();
         String plataforma = Videojuego.getString();

         Videojuego juego = new Videojuego(codigoUnico,nombre, precio, genero, compañia, clasificacionEdad,plataforma);
         this.agregarVideojuego(juego);

     }
     archivoEntrada.close();
     }
    public int BuscarVideojuegoCodigo(String codigoUnico){

        for (int i = 0; i < this.cantidadActual; i++) {
            if (this.arregloVideojuego[i].getCodigoUnico().equals(codigoUnico)){
                return i;

            }
        }
        return -1;
    }
    public int BuscarVideojuegoNombre(String nombre){
           for (int i = 0; i < cantidadActual; i++) {
            if (this.arregloVideojuego[i].getNombre().equalsIgnoreCase(nombre)){
                return i;
            }
        }
        return -1;
    }

    //Retorna la posicion dentro de la lista para su posterior uso en el main.
    public Videojuego obtenerPosicionVideojuego(int posicion){
        return this.arregloVideojuego[posicion];
    }
    public Videojuego[] getArregloVideojuego() {
        return arregloVideojuego;
    }

    public int getCantidadMaxima() {
        return cantidadMaxima;
    }

    public int getCantidadActual() {
        return cantidadActual;
    }

    public boolean agregarVideojuego(Videojuego juego){
        if (cantidadMaxima == cantidadActual) {
            return false;
        }

        for (int i = 0; i < this.cantidadActual; i++) {

            if (this.arregloVideojuego[i].getCodigoUnico().equalsIgnoreCase(juego.getCodigoUnico())) {
                return false;
            }
        }

        this.arregloVideojuego[cantidadActual] = juego;
        cantidadActual++;
        return true;
    }
    public void GeneradorDeDescuento(){
       String[] arreglodescuento=new String[this.cantidadMaxima];
       double numeroAleatorio=0;
       int numeroadevolver=0;

        for (int i = 0; i < this.cantidadActual; i++) {

            arreglodescuento[i]=(this.arregloVideojuego[i].getGenero());

            }
        numeroAleatorio=Math.random()*this.cantidadActual;
        numeroadevolver= (int) numeroAleatorio;
        this.descuentoAleatorio=arreglodescuento[numeroadevolver];

    }


    public String getDescuentoAleatorio() {
        return descuentoAleatorio;
    }
}
