package Services;
import Model.Empleado;
import Model.ListaEmpleados;
import Model.ListaVideojuego;
import ucn.*;
import ucn.StdIn;
import ucn.StdOut;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
    configuracion();

        }

        public static void configuracion(){

        //Los datos son fijos bajo los criterios del enunciado por ende no es necesario preguntar por el tamaño

        ListaEmpleados datosEmpleados= new ListaEmpleados(10);

        ListaVideojuego datosVideojuego = new ListaVideojuego(10);
        menu(datosEmpleados);
        menuPrincipal(datosVideojuego);

    }
    public static void menu(ListaEmpleados datosEmpleados){
        boolean llave=true;

        while (llave) {
            StdOut.println("*******************************");
            StdOut.println("Bienvenido al sistema de ventas");
            StdOut.println("*******************************");
            StdOut.println("Identificate");
            StdOut.println("*******************************");
            StdOut.println("1-Iniciar Sesión");
            StdOut.println("2-Cerrar Programa");

          String opcion= StdIn.readLine();
            switch (opcion){

                case "1" -> iniciarSesion(datosEmpleados);
                case "2" -> llave=false;
                default -> StdOut.println("Ingrese opcion valida");
            }
        }
    }

    //Inicio de sesion utiliza la Listaempleados la cual nombre datosEmpleados
    public static void iniciarSesion(ListaEmpleados datosEmpleados){
        System.out.println("Bienvenido, Ingrese sus credenciales para acceder");

        System.out.print("Usuario: ");
        String usuarioTeclado = StdIn.readAll();
        int posicion = datosEmpleados.buscarEmpleadoUsuario(usuarioTeclado);

        if (posicion != -1){

            Empleado usuario = datosEmpleados.obtenerPosicion(posicion);

            System.out.println("Bienvenido " + usuario.getUsuario()+ " porfavor ingrese su contraseña:");
        }
        else {
            System.out.println("Usuario incorrecto pruebe denuevo");
            iniciarSesion(datosEmpleados);
        }

        System.out.print("Contraseña: ");
        String contraseniaTeclado = StdIn.readAll();
        int posicion2 = datosEmpleados.buscarEmpleadoContrasenia(contraseniaTeclado);

        if (posicion2 != -1){
            Empleado contrasenia = datosEmpleados.obtenerPosicion(posicion2);

            System.out.println("Ingresaste: " + contrasenia.getContrasena());
            System.out.println("Bienvenido elija una de las siguiente opciones");
            //menuPrincipal();
        }
        else {
            System.out.println("Contraseña incorrecta pruebe denuevo");
            iniciarSesion(datosEmpleados);
        }



    }
    public static void menuPrincipal(ListaVideojuego datosVideojuegos){
        boolean llave2=true;

        while (llave2) {
            StdOut.println("*******************************");
            StdOut.println("Menu Principal");
            StdOut.println("Ingrese su opción");
            StdOut.println("1)vender videojuego");
            StdOut.println("2)Buscar Model.Videojuego");
            StdOut.println("(3) Registrar miembro");
            StdOut.println("4)Menú estadisticas");
            StdOut.println("5)cerrar sesion");

            String opcion= StdIn.readLine();
            switch (opcion){


               // case "1":vendervideojuegos();
               // case "2":buscarvideojuegos
                case "3":menuEstadisticas();
               // case "4":menu();
                default:StdOut.println("Ingrese opcion valida");
            }
        }

    }
    public static void menuEstadisticas(){
        boolean llave3=true;

        while (llave3) {
            StdOut.println("*******************************");
            StdOut.println("Menu Estadisticas");
            StdOut.println("Ingrese su opción");
            StdOut.println("1)Model.Videojuego más vendido");
            StdOut.println("2)Plataforma con mayor ventas");
            StdOut.println("3)Ventas a clientes registrados");
            StdOut.println("4)Imprimir ventas totales");
            StdOut.println("4)Trabajador con mas ventas");
            StdOut.println("4)menú anterior");

        }
    }
    }
