package Model;

import Model.Empleado;

public class ListaEmpleados {
    private Empleado[] arregloEmpleado;
    private  int cantidadMaxima;
    private  int cantidadActual;

    public ListaEmpleados(int cantidadMaxima){

        this.cantidadMaxima = cantidadMaxima;
        this.arregloEmpleado = new Empleado[this.cantidadMaxima];
        this.cantidadActual = 0;
    }


    //Metodos relacionados con el login
    public int buscarEmpleadoContrasenia(String contrasena){
        for (int i = 0; i < cantidadMaxima; i++) {
            if (this.arregloEmpleado[i].getContrasena().equalsIgnoreCase(contrasena)){
                return i;
            }
        }
        return -1;
    }

    public int buscarEmpleadoUsuario(String usuario){
        for (int i = 0; i < cantidadMaxima; i++) {
            if (this.arregloEmpleado[i].getUsuario().equalsIgnoreCase(usuario)){
                return i;
            }
        }
        return -1;
    }


    //No se porque se usa esto pero sin el no funca el buscar xd
    public Empleado obtenerPosicion(int posicion){

        return this.arregloEmpleado[posicion];
    }

    public Empleado[] getArregloEmpleado() {
        return arregloEmpleado;
    }

    public int getCantidadMaxima() {
        return cantidadMaxima;
    }

    public int getCantidadActual() {
        return cantidadActual;
    }
}
