package Model;

import ucn.ArchivoEntrada;

import java.io.IOException;

public class ListaVideojuego {
    private Videojuego[] arregloVideojuego;
    private  int cantidadMaxima;
    private  int cantidadMinima;

    public ListaVideojuego(int cantidadMaxima) {
       if(cantidadMaxima<=0){
           throw new IllegalArgumentException("La cantidad no puede ser cero");
       }
        this.cantidadMaxima = cantidadMaxima;
        this.arregloVideojuego=new Videojuego[this.cantidadMaxima];
        this.cantidadMinima=0;
    }

    //Verificar la lectura de archivos principalmente la forma de ingresar los mismos

    /**
     public void lecturaArchivo(String nombreArchivo) throws IOException {

     Videojuego videojuego;

     ArchivoEntrada archivoEntrada = new ArchivoEntrada(nombreArchivo);

     while (!archivoEntrada.isEndFile()) {

     String[] linea = archivoEntrada;
     String codigoUnico = linea[0];
     String nombre = linea[1];
     double precio = Integer.parseInt(linea[2]);
     String genero = linea[3];
     int clasificacionEdad = Integer.parseInt(linea [4]);
     String plataforma = linea [5];
     }
     }
     /* *
     *
     * @return
     */

    public int BuscarVideojuegoCodigo(String codigoUnico){
        for (int i = 0; i < cantidadMaxima; i++) {
            if (this.arregloVideojuego[i].getCodigoUnico().equalsIgnoreCase(codigoUnico)){
                return i;
            }
        }
        return -1;
    }
    public int BuscarVideojuegoNombre(String nombre){
        for (int i = 0; i < cantidadMaxima; i++) {
            if (this.arregloVideojuego[i].getNombre().equalsIgnoreCase(nombre)){
                return i;
            }
        }
        return -1;
    }
    public Videojuego[] getArregloVideojuego() {
        return arregloVideojuego;
    }

    public int getCantidadMaxima() {
        return cantidadMaxima;
    }

    public int getCantidadMinima() {
        return cantidadMinima;
    }
}
