package Services;
import Model.Empleado;
import Model.ListaEmpleados;
import Model.ListaVideojuego;
import Model.Videojuego;
import ucn.*;
import ucn.StdIn;
import ucn.StdOut;

import java.io.IOException;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) throws IOException {
    configuracion();

        }

        //Modificaciones principales 21-04:

        //Cambio dentro de los parametros para "menu" , "menuprincipal" y "iniciarSesion"
        //Con el fin de la comunicación entre metodos dentro del main.

        // cambio dentro de "String Usuario Stdin.readAll()" se cambio a String Usuario Stdin.ReadLine()"
        // ya que no leia correctamente el documento de texto

        // Añadido "BuscarVideojuego"

        //nota: ventaVideojuego deberia funcionar similar a la estructura de busquedaVideojuego
        //      considerando claro otros algoritmos para añadir a las estadisticas. ni idea ahi la verdad

        //nota: Las validaciones son los amigos que hicimos en el camino

        //"buscarVideojuegos" tiene errores solo funciona correctamente la busqueda por codigo y printea lo demas sin
        // haberse cumplido la condición probablemente sea
        // un mal manejo de la estructura de las condicionales.


        public static void configuracion() throws IOException {

        //Los datos son fijos bajo los criterios del enunciado por ende no es necesario preguntar por el tamaño

        ListaEmpleados datosEmpleados= new ListaEmpleados(10);
        ListaVideojuego datosVideojuego = new ListaVideojuego(10);

        String Archivo1=("Juegos.txt");
            String Archivo2=("Trabajadores.txt");
        datosVideojuego.lecturaArchivo(Archivo1);
        datosEmpleados.lecturaArchivo(Archivo2);


            menu(datosEmpleados, datosVideojuego);
        menuPrincipal(datosVideojuego);

    }

    public static void menu(ListaEmpleados datosEmpleados, ListaVideojuego datosVideojuegos){
        boolean llave=true;

        while (llave) {
            StdOut.println("*******************************");
            StdOut.println("Bienvenido al sistema de ventas");
            StdOut.println("*******************************");
            StdOut.println("Identificate");
            StdOut.println("*******************************");
            StdOut.println("1-Iniciar Sesión");
            StdOut.println("2-Cerrar Programa");

          String opcion= StdIn.readLine();
            switch (opcion){

                case "1" -> iniciarSesion(datosEmpleados, datosVideojuegos);
                case "2" -> llave=false;
                case "3" -> menuPrincipal(datosVideojuegos);
                default -> StdOut.println("Ingrese opcion valida");
            }
        }
    }

    //Inicio de sesion utiliza la Listaempleados la cual nombre datosEmpleados
    public static void iniciarSesion(ListaEmpleados datosEmpleados, ListaVideojuego datosVideojuegos){
        System.out.println("Bienvenido, Ingrese sus credenciales para acceder");

        System.out.print("Usuario: ");
        String usuarioTeclado = StdIn.readLine();   //PORQUE O RABANOS FUNCIONA COM O REDLINE, ESTOU TENTANDO DESCOBRIR O MOTIVO HÁ UMA HORA. VOU ACESSAR O SITE ****** atte: juan
        int posicion = datosEmpleados.buscarEmpleadoUsuario(usuarioTeclado);

        if (posicion != -1){

            Empleado usuario = datosEmpleados.obtenerPosicion(posicion);

            System.out.println("Bienvenido " + usuario.getUsuario()+ " porfavor ingrese su contraseña:");
        }
        else {
            System.out.println("Usuario incorrecto pruebe denuevo");
            iniciarSesion(datosEmpleados, datosVideojuegos);
        }

        System.out.print("Contraseña: ");
        String contraseniaTeclado = StdIn.readLine();
        int posicion2 = datosEmpleados.buscarEmpleadoContrasenia(contraseniaTeclado);

        if (posicion2 != -1){
            Empleado contrasenia = datosEmpleados.obtenerPosicion(posicion2);

            System.out.println("Ingresaste: " + contrasenia.getContrasena());
            System.out.println("Bienvenido elija una de las siguiente opciones");
            menuPrincipal(datosVideojuegos);
        }
        else {
            System.out.println("Contraseña incorrecta pruebe denuevo");
            iniciarSesion(datosEmpleados, datosVideojuegos);
        }



    }

    public static void menuPrincipal(ListaVideojuego datosVideojuegos){
        boolean llave2=true;

        while (llave2) {
            StdOut.println("*******************************");
            StdOut.println("Menu Principal");
            StdOut.println("Ingrese su opción");
            StdOut.println("1) vender videojuego");
            StdOut.println("2) Buscar Videojuego");
            StdOut.println("3) Registrar miembro");
            StdOut.println("4) Menú estadisticas");
            StdOut.println("5) cerrar sesion");

            String opcion= StdIn.readLine();
            switch (opcion){

                //case "1":vendervideojuegos(datosVideojuegos);
                case "2":buscarvideojuegos(datosVideojuegos);
               // case "3":menuEstadisticas();
               // case "4":menu();
                default:StdOut.println("Ingrese opcion valida");
            }
        }

    }

    //buscarVideojuego:
    //Se le pide al usuario ingresar por teclado el codigo unico o nombre(Aun no funciona correctamente pero esta es
    // la estructura), consecuentemente utiliza el dato ingresado para comparar dentro de la "ListaVideojuego" en base a
    // "BuscarVideojuego"
    // Si lo encuentra declaramos a la clase "Videojuego" y la nombramos en este caso "codigo" a continuación
    // printea los datos dentro de la clase llamandolos por ejemplo con la funcion "codigo.getCodigounico()"
    // cabe añadir que los datos son obtenidos del documento de texto (Juegos.txt)
    // atte: Juan
    public static void buscarvideojuegos(ListaVideojuego datosVideojuegos){
        System.out.println("Ingrese el nombre o codigo unico del videojuego");
        String buscarDatoIngresado = StdIn.readLine();
        int posicion = datosVideojuegos.BuscarVideojuegoCodigo(buscarDatoIngresado);
        int posicion2 = datosVideojuegos.BuscarVideojuegoNombre(buscarDatoIngresado);

        if (posicion != -1){
            Videojuego codigo = datosVideojuegos.obtenerPosicionVideojuego(posicion);
            System.out.println("/////Videojuego///// \n" + "Codigo:" + codigo.getCodigoUnico() +"\n" + "Nombre: " +
                    codigo.getNombre() + "\n" + "Precio: " +codigo.getPrecio()  +
                    "\n" + "Genero: "+ codigo.getGenero()  + "\n" + "Clasificación: " +
                    codigo.getClasificacionEdad()  + "\n" + "Desarrolladora: " + codigo.getCompañia()
                    + "\n" +  "Plataforma: " + codigo.getPlataforma());
            menuPrincipal(datosVideojuegos);
        }
        else if (posicion2 != -1){
            Videojuego nombre = datosVideojuegos.obtenerPosicionVideojuego(posicion);
            System.out.println("/////Videojuego///// \n" + "Codigo:" + nombre.getCodigoUnico() +"\n" + "Nombre: " +
                    nombre.getNombre() + "\n" + "Precio: " +nombre.getPrecio()  +
                    "\n" + "Genero: "+ nombre.getGenero()  + "\n" + "Clasificación: " +
                    nombre.getClasificacionEdad()  + "\n" + "Desarrolladora: " + nombre.getCompañia()
                    + "\n" +  "Plataforma: " + nombre.getPlataforma());
            menuPrincipal(datosVideojuegos);
        }
        else {
            System.out.println("Videojuego no encontrado intente denuevo");
            buscarvideojuegos(datosVideojuegos);
        }
    }
    public static void menuEstadisticas(){
        boolean llave3=true;

        while (llave3) {
            StdOut.println("*******************************");
            StdOut.println("Menu Estadisticas");
            StdOut.println("Ingrese su opción");
            StdOut.println("1)Model.Videojuego más vendido");
            StdOut.println("2)Plataforma con mayor ventas");
            StdOut.println("3)Ventas a clientes registrados");
            StdOut.println("4)Imprimir ventas totales");
            StdOut.println("4)Trabajador con mas ventas");
            StdOut.println("4)menú anterior");

        }
    }
    }
