package Model;
import ucn.ArchivoEntrada;
import ucn.Registro;

import java.io.IOException;

public class ListaVideojuego {
    private Videojuego[] arregloVideojuego;
    private  int cantidadMaxima;
    private  int cantidadMinima;

    public ListaVideojuego(int cantidadMaxima) {
       if(cantidadMaxima<=0){
           throw new IllegalArgumentException("La cantidad no puede ser cero");
       }
        this.cantidadMaxima = cantidadMaxima;
        this.arregloVideojuego=new Videojuego[this.cantidadMaxima];
        this.cantidadMinima=0;
    }

    //Verificar la lectura de archivos principalmente la forma de ingresar los mismos


     public void lecturaArchivo(String nombreArchivo) throws IOException {                //logica de agregar videojuegos, ordeno el codigo luiego perdon que son las 1:41 de la mañana
     Videojuego videoJuego;                                                                 //declaramos videjuegos
     int cont=0;                                                                            //crearemos los contadores utiles para la funcion , contador sirve para que los lugar4es en la lista corresponda
     int iteraciones=0;                                                                     // con la posicion real mientras que iteraciones lleva un registro del valor real de el numero de veces que agregamos un dato a la lista
     String[] linea=new String[500];                                                        // creamos un arreglo con una excesiva cantidad para que no se llene el arreglo
     ArchivoEntrada archivoEntrada = new ArchivoEntrada(nombreArchivo);                     //declaramos el archivo entrada

     while (!archivoEntrada.isEndFile()) {                                                    //condicional para leer la cantidad variable de datos

         Registro Videojuego=archivoEntrada.getRegistro();                                  //creamos enl registro para poder extraer datos
         String codigoUnico = Videojuego.getString();                                      //Usaremos nuestro registro para sacar la informacion que hemos adquiridos
         String nombre=Videojuego.getString();
         double precio =Videojuego.getDouble();                                           //sacamaos el precio como double del programa
         String genero = Videojuego.getString();
         String compañia= Videojuego.getString();
         String clasificacionEdad =Videojuego.getString();
         String plataforma = Videojuego.getString();
         if(codigoUnico!=null){                                                       // un if totaltalmente inecesario, pero me da miedfo tocar mas: Juan: Happens

             linea[cont]=codigoUnico;                                                       // agreghamos los datos del registro a una matrixx uxiliar para guardar dattos que usaremos para guardar de manera optima los datos
             linea[cont+1]=nombre;
             linea[cont+2]= String.valueOf(precio);
             linea[cont+3]= genero;
             linea[cont+4]= compañia;
             linea[cont+5]=clasificacionEdad;
             linea[cont+6]= plataforma;
             cont=cont+7;                                                               // aumentamos en 7 el numero de datos  ya que esa es la cantidad de que se agregan , revisar si ews valido con el ayudante o idear metodo alternaticvos
             iteraciones++;
         }
     }
     int cantidadAgregada=0;
     for (int i = 0; i < iteraciones; i++) {                                            //agrga un objetto videojuego a la lista , deber de sacar con un get dato lo que quieras juan  cuando trabajes con ello suerte

             String dato=(linea[cantidadAgregada+2]);
             this.arregloVideojuego[i]= new Videojuego(linea[cantidadAgregada],linea[cantidadAgregada+1], parceadaor(dato), linea[cantidadAgregada+3], linea[cantidadAgregada+4], linea[cantidadAgregada+5],linea[cantidadAgregada+6]);
             cantidadAgregada=cantidadAgregada+7;
         }
         archivoEntrada.close();

     }
     public double parceadaor(String dato){                                                 //parcsea el dato del valor ya que la lsita aux era un sstring
        double valor= Double.parseDouble(dato);
        return valor;
     }

    public int BuscarVideojuegoCodigo(String codigoUnico){
        for (int i = 0; i < cantidadMaxima; i++) {
            if (this.arregloVideojuego[i].getCodigoUnico().equalsIgnoreCase(codigoUnico)){
                return i;
            }
        }
        return -1;
    }
    public int BuscarVideojuegoNombre(String nombre){
        for (int i = 0; i < cantidadMaxima; i++) {
            if (this.arregloVideojuego[i].getNombre().equalsIgnoreCase(nombre)){
                return i;
            }
        }
        return -1;
    }

    //Retorna la posicion dentro de la lista para su posterior uso en el main.
    public Videojuego obtenerPosicionVideojuego(int posicion){
        return this.arregloVideojuego[posicion];
    }
    public Videojuego[] getArregloVideojuego() {
        return arregloVideojuego;
    }

    public int getCantidadMaxima() {
        return cantidadMaxima;
    }

    public int getCantidadMinima() {
        return cantidadMinima;
    }


}
