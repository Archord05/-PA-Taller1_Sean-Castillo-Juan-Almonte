package Model;

import Model.Empleado;
import ucn.ArchivoEntrada;
import ucn.Registro;

import java.io.IOException;

public class ListaEmpleados {
    private Empleado[] arregloEmpleado;
    private  int cantidadMaxima;
    private  int cantidadActual;

    public ListaEmpleados(int cantidadMaxima){

        this.cantidadMaxima = cantidadMaxima;
        this.arregloEmpleado = new Empleado[this.cantidadMaxima];
        this.cantidadActual = 0;
    }

    public void lecturaArchivo(String nombreArchivo) throws IOException {
        Empleado Empleado;
        int cont = 0;
        int iteraciones = 0;
        int cantidadAgregada=0;
        String[] linea = new String[500];
        ArchivoEntrada archivoEntrada = new ArchivoEntrada(nombreArchivo);

        while (!archivoEntrada.isEndFile()) {   //misma explicacion dem videoojuegos se aplica aqui

            Registro empleado = archivoEntrada.getRegistro();
            String codigoUnico = empleado.getString();
            String nombre = empleado.getString();

                linea[cont] = codigoUnico;
                linea[cont + 1] = nombre;
                cont=cont+2;
                iteraciones++;
        }
        for (int i = 0; i < iteraciones; i++) {
         this.arregloEmpleado[i]=new Empleado(linea[cantidadAgregada],linea[cantidadAgregada+1]);
            cantidadAgregada=cantidadAgregada+2;
        }
        archivoEntrada.close();
    }
    //Metodos relacionados con el login
    public int buscarEmpleadoContrasenia(String contrasena){
        for (int i = 0; i < cantidadMaxima; i++) {
            if (this.arregloEmpleado[i].getContrasena().equalsIgnoreCase(contrasena)){
                return i;
            }
        }
        return -1;
    }

    public int buscarEmpleadoUsuario(String usuario){
        for (int i = 0; i < cantidadMaxima; i++) {
            if (this.arregloEmpleado[i].getUsuario().equalsIgnoreCase(usuario)){
                return i;
            }
        }
        return -1;
    }


    //No se porque se usa esto pero sin el no funca el buscar xd
    public Empleado obtenerPosicion(int posicion){
        return this.arregloEmpleado[posicion];
    }

    public Empleado[] getArregloEmpleado() {
        return arregloEmpleado;
    }

    public int getCantidadMaxima() {
        return cantidadMaxima;
    }

    public int getCantidadActual() {
        return cantidadActual;
    }
}
