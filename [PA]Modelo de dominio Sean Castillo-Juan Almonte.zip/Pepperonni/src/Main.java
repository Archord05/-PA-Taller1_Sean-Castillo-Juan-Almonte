
public class Main {
    public static void main(String[] args) {
        System.out.println("SilkSong sale en enero de 2025");
    }
}